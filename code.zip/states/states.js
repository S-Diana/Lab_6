import React, {useEffect, useState} from 'react';
import { Dimensions } from "react-native";

export const bottom = {
    dark: false,
    colors: {
        primary: '#8469A9',
        background: 'rgb(242, 242, 242)',
        card: '#F7C4AF',
        text: '#8469A9',
        border: 'rgb(199, 199, 204)',
        notification: 'rgb(255, 69, 58)',
    },
};

export const top = {
    dark: false,
    colors: {
        primary: '#F7C4AF',
        background: 'rgb(242, 242, 242)',
        card: '#F7C4AF',
        text: 'rgb(28, 28, 30)',
        border: 'rgb(199, 199, 204)',
        notification: 'rgb(255, 69, 58)',
    },
}

export const btn = {
    colors: {
        primary: '#8469A9',
        text: 'rgb(242, 242, 242)',
    },
};

export const data = [0, 20, 35, 45, 50, 55, 60, 65, 70, 75, 80];

export const useScreenDimensions = () => {
    const [screenData, setScreenData] = useState(Dimensions.get('screen'));

    useEffect(() => {
        const onChange = (result) => {
            setScreenData(result.screen);
        };

        Dimensions.addEventListener('change', onChange);

        return () => Dimensions.removeEventListener('change', onChange);
    });

    return { ...screenData, isLandscape: screenData.width > screenData.height };
};

