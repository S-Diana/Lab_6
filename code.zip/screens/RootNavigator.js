import React from 'react';
import { View } from 'react-native';
import { bottom } from '../states/states'
import Icon from 'react-native-vector-icons/FontAwesome'
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import FilmDetails from "./FilmDetails";
import Pie_Chart from "./Pie_Chart";
import AddItems from "./AddItems";
import First from "./First";
import Image from "./Image";
import Films from './Films'

const Stack = createStackNavigator();

const filmsScreen = () => {
    return(
        <Stack.Navigator initialRouteName="Films">
            <Stack.Screen name="Films" component={ Films } options={{ headerShown: false, tabBarLabel: 'Films' }} />
            <Stack.Screen name="Details" component={FilmDetails} />
            <Stack.Screen name="AddItems" component={AddItems} />
        </Stack.Navigator>
    )
}


const Tab = createMaterialBottomTabNavigator();

const RootNavigator = () => {
    return (
        <NavigationContainer theme={ bottom }>
            <Tab.Navigator
                shifting={true}
                sceneAnimationEnabled={true}
                initialRouteName="First">
                <Tab.Screen
                    name="First"
                    component={First}
                    options={{
                        tabBarLabel: 'First',
                        tabBarIcon: () => (
                            <View>
                                <Icon
                                    style={[{color: '#F9F3E7'}]}
                                    size={25}
                                    name={'instagram'}
                                />
                            </View>
                        ),
                    }}
                />
                <Tab.Screen
                    name="Pie_Chart"
                    component={Pie_Chart}
                    options={{
                        tabBarLabel: 'Pie_Chart',
                        tabBarIcon: () => (
                            <View>
                                <Icon
                                    style={[{color: '#F9F3E7'}]}
                                    size={25}
                                    name={'xing'}
                                />
                            </View>
                        ),
                    }}
                />
                <Tab.Screen
                    name='Films'
                    component={filmsScreen}
                    options={{
                        tabBarLabel: 'Films',
                        tabBarIcon: () => (
                            <View>
                                <Icon
                                    style={[{color: '#F9F3E7'}]}
                                    size={23}
                                    name={'film'}
                                />
                            </View>
                        ),
                    }}
                />
                <Tab.Screen
                    name='Image'
                    component={Image}
                    options={{
                        tabBarLabel: 'Image',
                        tabBarIcon: () => (
                            <View>
                                <Icon
                                    style={[{color: '#F9F3E7'}]}
                                    size={25}
                                    name={'th'}
                                />
                            </View>
                        ),
                    }}
                />
            </Tab.Navigator>
        </NavigationContainer>
    );
}
export default RootNavigator
