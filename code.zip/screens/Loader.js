import React, { useState } from 'react';
import { View, Modal, ActivityIndicator, Dimensions } from 'react-native';
import { useScreenDimensions } from '../states/states'

const Loader = ({ loading }) => {

    const screenData = useScreenDimensions();
    const [loadInTime, setLoadInTime] = useState(loading);

    setTimeout( () => { setLoadInTime(false) },1000);

    return (
        <Modal transparent={true} animationType={'none'} visible={ loadInTime } supportedOrientations={['portrait', 'landscape']}>
            <View style={{ height: Dimensions.get('screen').height, alignItems: 'center', flexDirection: screenData.isLandscape ? 'row' : 'column', justifyContent: 'space-around', backgroundColor: '#8469A9'}}>
                <ActivityIndicator animating={ loadInTime } size={"large"} color="#3d084f"/>
            </View>
        </Modal>
    )
}

export default Loader;
