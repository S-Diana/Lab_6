import React from 'react';
import { View, Dimensions, Image, Text, ScrollView, TouchableNativeFeedback } from 'react-native';
import { Card } from 'react-native-elements'
import { top, useScreenDimensions } from '../states/states'
import Icon from 'react-native-vector-icons/FontAwesome'
import { Appbar } from 'react-native-paper';
import SearchBar from "react-native-dynamic-search-bar";

function Films ({ navigation }) {

    const dim = Dimensions.get('screen')
    const screenData = useScreenDimensions();
    const [films, setFilms] = React.useState([])
    const [search, setTxtSearch] = React.useState('')


    const rem = (arr, key) => [...new Map(arr.map(item => [item[key], item])).values()]

    const filter = (items, term) => {
        if(term.length === 0 || term.trim().length === 0) { return items }
        return items.filter((item) => {if(item.Title.replace(/[^a-zA-Z ]/g, "").toLowerCase().indexOf(term)> -1){return (item)}})
    }
    const currData = filter(films, search)

    const remAll = async (text) => {
        let filmsDataInFunc = []
        const parsedTxt = text.toLowerCase().replace(/[^a-zA-Z ]/g, "").replace(/\s+/g, ' ').trim().replace(/,/g, '')
        setTxtSearch(parsedTxt)
        if( search.length <= 2) {
            return null
        } else if ( search.length >= 2 ) {
            let url = `https://www.omdbapi.com/?apikey=2965961d&s=${parsedTxt}&page=1`
            const fetchResult = await fetch(url);
            const loadedData = await fetchResult.json();
            filmsDataInFunc = [...filter(films, parsedTxt), ...loadedData.Search]
        }
        setFilms(rem([...filmsDataInFunc, ...films], 'imdbID' ))
    }

    const del = (id) => {
        const idx = films.findIndex((el) => el.imdbID === id)
        setFilms([...films.slice(0, idx),...films.slice(idx + 1)])
    };

    return (
        <ScrollView>
            <View>
                <Appbar.Header theme={top}>
                    <Appbar.Action icon="home"/>
                    <SearchBar
                        style={{flex: 1}}
                        placeholder="Search"
                        onClearPress={() => {setTxtSearch('')}}
                        onChangeText={(txt) => remAll(txt)}
                    />
                    <Appbar.Action
                        icon="plus"
                        onPress={() => {navigation.navigate('AddItems', {films:  films, setFilms: setFilms})}}
                    />
                </Appbar.Header>
            </View>
            <View style={{ flex: 1, flexDirection: 'row', flexWrap: 'wrap', alignItems: "center", justifyContent: "center" }}>
                {
                    search.length <= 2 ?
                        <View style={{height: dim.height, paddingTop: screenData.isLandscape ? '15%' : '65%', flexDirection:'column', alignItems:'center'}}>
                            <Text style={{fontSize: 20}}>
                               Empty there
                            </Text>
                        </View> :
                    currData.length === 0 ?
                        <View style={{ height: dim.height, paddingTop: screenData.isLandscape ? '15%' : '65%', flexDirection:'column', alignItems:'center'}}>
                            <Text style={{fontSize: 20}}>
                                Try something else
                            </Text>
                        </View> :
                    currData.map((item, index) => {
                        return (
                            <TouchableNativeFeedback
                                style={{ flex: 0, alignItems: "center", justifyContent: "space-between" }}
                                key={index}
                                onPress={() => {navigation.navigate('Details', {Id: item.imdbID})}}
                            >
                                <Card containerStyle={{ borderRadius: 35, backgroundColor: '#bdaed1' }}>
                                    <View style={{ marginLeft: '47%', width: 20}}>
                                        <Icon onPress={() => {del(item.imdbID)}} style={[{color: '#3d084f', flex: 0}]} size={25} name={'trash'}/>
                                    </View>
                                    <View style={{ flex: 1, flexDirection: 'row', flexWrap: 'wrap'}}>
                                        <Text style={{ fontSize: 20, width: 250, flex: 0, textAlign: 'center', alignItems: "center", marginBottom: 10 }}>
                                            {item.Title.length >= 60 ? item.Title.slice(0, 50 - 1) + '…' : item.Title}
                                        </Text>
                                    </View>
                                    <View style={{ height: 300, alignItems: "center", justifyContent: "center" }}>
                                        <Image
                                            resizeMode="cover"
                                            source={ item.image === 'N/A' || item.image === '' ? require('../assets/prpl.png') : { uri: item.Poster } }
                                            style={ screenData.isLandscape ?
                                                { height: 250, width: 150, marginBottom: 10 } :
                                                { height: 250, width: 165, borderRadius: 20, marginBottom: 10 }}
                                        />
                                        <View style={{ flexDirection: 'row', alignItems: "center", justifyContent: "space-between" }}>
                                            <Text style={{ fontSize: 20, flex: 0, textAlign: 'center', alignItems: "center", flexWrap: 'wrap' }}>{item.Type === '' ? 'movie' : item.Type}</Text>
                                            <Text style={{ fontSize: 20, flex: 0, textAlign: 'center', alignItems: "center", flexWrap: 'wrap' }}>{item.Year === '' ? ' unknown' : ' ' + item.Year}</Text>
                                        </View>
                                    </View>
                                </Card>
                            </TouchableNativeFeedback>
                        )
                    })
                }
            </View>
        </ScrollView>
    )
}

export default Films
