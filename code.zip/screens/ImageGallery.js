import React from 'react';
import { View } from 'react-native';
import Image from 'react-native-image-progress';

const ImageGallery = ({ elements, width, height }) => {

    const img = { width: width, height: height }
    const img2 = { width: width * 2, height: height * 2 };
    const img3 = { width: width * 3, height: height * 3 };

    const getComponent = (uri, optionsStyles = img) => (
        <Image
            style={optionsStyles}
            source={uri}
            threshold={150}
        />
    );
    return (
        <>
            <View style={{display: "flex", flexDirection: "row"}}>
                <View style={{display: "flex", flexDirection: "column"}}>
                    {elements[0] && getComponent(elements[0], img3)}
                    <View style={{display: "flex", flexDirection: "row"}}>
                        {elements[3] && getComponent(elements[3])}
                        {elements[4] && getComponent(elements[4])}
                        {elements[5] && getComponent(elements[5])}
                    </View>
                </View>
                <View style={{display: "flex", flexDirection: "column"}}>
                    {elements[1] && getComponent(elements[1], img2)}
                    {elements[2] && getComponent(elements[2], img2)}
                </View>
            </View>
        </>
    );
};

export default ImageGallery
