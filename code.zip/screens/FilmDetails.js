import React from 'react';
import { View, Image, Text, ScrollView } from 'react-native';
import { useScreenDimensions } from '../states/states'
import Loader from "./Loader";

const FilmDetails = ({route}) => {

    const { Id } = route.params;
    const [filmInfo, setFilmInfo] = React.useState([])
    const screenData = useScreenDimensions();

    React.useEffect(() => {
        let cleanupFunction = false;
        const fetchData = async () => {
            try {
                fetch(`https://www.omdbapi.com/?apikey=2965961d&i=${Id}`).then(response => response.json() ).then(data => setFilmInfo([data]) )
                if(!cleanupFunction) { setFilmInfo(['']); }
            } catch (e) { console.error(e.message) }
        }; fetchData();
        return () => cleanupFunction = true;
    }, []);

    return (
        <ScrollView>
            <View>
                <Loader loading={true}/>
                <View style={{ flex: 0, alignItems: 'center', justifyContent: 'center' }}>
                    {
                        filmInfo[0] === '' ?
                            <View style={{ flex: 1, marginTop: screenData.isLandscape ? '18%' : '65%', justifyContent: 'center', flexDirection:'column', alignItems:'center' }}>
                                <Text style={{ fontSize: 20 }}>TEST</Text>
                            </View> :
                            filmInfo.map((item, index) => {
                                return(
                                    <View key={index}>
                                        <View>
                                            <Image
                                                resizeMode="cover"
                                                source={ item.image === 'N/A' || item.image === '' ? require('../assets/prpl.png') : { uri: item.Poster } }
                                                style={screenData.isLandscape ? { borderRadius: 30, marginBottom: 20, marginTop: 25, height: 360, width: 255}: { borderRadius: 30, marginLeft: '3%',  marginBottom: 20, marginTop: 25, height: 260, width: 155 }}
                                            />
                                        </View>
                                        <View style={{ marginLeft: 10, marginRight: 10}}>
                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Title</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Title}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Year</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Year}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Rating</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.imdbRating}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                People voted</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.imdbVotes}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Genre</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Genre}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Runtime</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Runtime}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Type</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Type}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Director</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Director}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Writer</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Writer}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Cast</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Actors}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Description</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Plot}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Released</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Released}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Language</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Language}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Country</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Country}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Production</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Production}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Awards</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Awards}</Text>

                                            <Text style={{ color: '#292929', fontSize: 20, marginBottom: 5, fontWeight: 'bold'}}>
                                                Rated</Text>
                                            <Text style={{ color: '#292929', fontSize: 18, marginBottom: 5 }}>
                                                {item.Rated}</Text>
                                        </View>
                                    </View>
                                )
                            }
                        )
                    }
                </View>
            </View>
        </ScrollView>
    )
}

export default FilmDetails
