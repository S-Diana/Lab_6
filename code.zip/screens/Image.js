import React, { useState } from 'react';
import { View, Text, ScrollView, StatusBar } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Appbar } from 'react-native-paper';
import SearchBar from "react-native-dynamic-search-bar";
import ImageGallery from "./ImageGallery";
import { useScreenDimensions, top } from '../states/states'

const Image = () => {

    const [images, setImages] = useState([]);

    React.useEffect(() => {
        const url = `https://pixabay.com/api/?key=19193969-87191e5db266905fe8936d565&q=small+animals&image_type=photo&per_page=18`;
        let cleanupFunction = false;
        const fetchData = async () => {
            try {
                const fetchResult = await fetch(url);
                const loadedData = await fetchResult.json();
                const loadedDataURIs = loadedData['hits'].map((lD) => ({ uri: lD['largeImageURL'] }));
                setImages(loadedDataURIs)
            } catch (e) {
                console.error(e.message)
            }
        }; fetchData();
        return () => cleanupFunction = true;
    }, []);

    const pickImage = async () => {
        const pickedImage = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: false, quality: 1
        });
        if (pickedImage.cancelled) {
            console.log('canceled')
        } else {
            setImages(prevState => [...prevState, { uri: pickedImage.uri }])
        }
    };

    const screenData = useScreenDimensions();

    const gallery = splitter(images).map( item => <ImageGallery key={ item[0].uri } elements={ item } width={ screenData.width / 5 } height={ screenData.isLandscape ? screenData.height / 2.5 : screenData.height / 8 } /> );

    return (
        <>
            <View>
                <Appbar.Header theme={top}>
                    <Appbar.Action icon="home"/>
                    <SearchBar placeholder='Search' style={{flex: 1}}/>
                    <Appbar.Action icon="plus" onPress={pickImage}/>
                </Appbar.Header>
            </View>
            <View style={{flex: 1, marginTop: StatusBar.currentHeight}}>
                {
                    images.length !== 0 ?
                        <ScrollView style={screenData.isLandscape ? { display: "flex", flexWrap: "wrap", flexDirection: "row" } : { display: "flex", flexWrap: "wrap", flexDirection: "row" }}>
                            { gallery }
                        </ScrollView> : null
                }
            </View>
        </>
    );
};

const splitter = (arr = [], maxArrSize = 6) => {
    const result = [];
    for (let i = 0; i < Math.ceil(arr.length / maxArrSize); i++) {
        result[i] = arr.slice(i * maxArrSize, (i * maxArrSize) + maxArrSize);
    }
    return result;
};

export default Image
