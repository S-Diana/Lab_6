import React, { useState } from "react";
import { View, Text, ScrollView, TouchableOpacity } from 'react-native'
import { btn } from "../states/states";
import { Button } from "react-native-elements";
import { FloatingLabelInput } from 'react-native-floating-label-input';

const AddItems = ({ navigation, route }) => {

    const { films } = route.params;
    const { setFilms } = route.params;
    const [title, setTitle] = useState('');
    const [type, setType] = useState('');
    const [year, setYear] = useState('');

    function sendData(data, setNewData) {
        try {
            const num = parseInt(year);
            let Idx = 50
            if (isNaN(num)) {
                setYear('should be number')
                setTimeout(() => {
                    setYear('')
                }, 2000);
            } else {
                const newFilm = { Title: title, Year: year, imdbID: Idx++, Type: type, Poster: ''}
                const newBooksData = [...data, newFilm]
                setNewData(newBooksData)
                navigation.navigate('Films')
            }
        } catch( e ) { console.log( e ) }
    }

    return (
        <ScrollView keyboardShouldPersistTaps="handled">
            <View style={{padding: 50, flex: 1}}>
                <View style={{marginBottom: 20}}>
                    <FloatingLabelInput
                        countdownLabel="chars left"
                        placeholder={''}
                        style={{color: '#fff'}}
                        label={'Title'}
                        value={title}
                        rightComponent={(
                            <TouchableOpacity
                                style={{ alignContent:'center', justifyContent:'center' }}
                                onPress={()=>{setTitle('')}}>
                                <Text>✕</Text>
                            </TouchableOpacity>
                        )}
                        onChangeText={(val) => setTitle(val)}
                    />
                </View>
                <View style={{marginBottom: 20}}>
                    <FloatingLabelInput
                        label={'Type'}
                        value={type}
                        rightComponent={(
                            <TouchableOpacity
                                style={{ alignContent:'center', justifyContent:'center' }}
                                onPress={()=>{ setType('')}}>
                                <Text>✕</Text>
                            </TouchableOpacity>
                        )}
                        onChangeText={(val) => setType(val)}
                    />
                </View>
                <View style={{marginBottom: 20}}>
                    <FloatingLabelInput
                        keyboardType="numeric"
                        label={'Year'}
                        value={year}
                        mask={'9999'}
                        rightComponent={(
                            <TouchableOpacity
                                style={{alignContent:'center', justifyContent:'center'}}
                                onPress={()=>{ setYear('')}}>
                                <Text>✕</Text>
                            </TouchableOpacity>
                        )}
                        onChangeText={(val) => setYear(val)}
                    />
                </View>
                <View style={{ flex: 1, alignItems: 'center' }}>
                    <Button
                        onPress={() => { sendData(films, setFilms)} }
                        theme={btn}
                        title="Add"
                        buttonStyle={{ width: 150 }}
                    />
                </View>
            </View>
        </ScrollView>
    )
}

export default AddItems
