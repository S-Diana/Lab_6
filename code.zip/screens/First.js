import React from "react";
import { View, Text } from 'react-native'

const First = () => {
    return (
        <View style={{ flex: 1,  justifyContent: 'center', flexDirection:'column', alignItems:'center' }}>
            <Text style={{ fontSize: 20 }}>Сачаво Диана</Text>
            <Text style={{ fontSize: 20 }}>Група ІВ-83</Text>
            <Text style={{ fontSize: 20 }}>ЗК ІВ-8324</Text>
        </View>
    )
}

export default First
